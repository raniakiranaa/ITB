public interface TrackableVehicle extends Vehicle, Trackable {
    
}
