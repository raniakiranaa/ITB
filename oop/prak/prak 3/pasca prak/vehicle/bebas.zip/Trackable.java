public interface Trackable {
    public String getPlateNumber();
    public Point getGPSPosition();
}
