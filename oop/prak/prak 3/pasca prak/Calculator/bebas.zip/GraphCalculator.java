public interface GraphCalculator extends Calculator, GraphUpgrade {
    
}