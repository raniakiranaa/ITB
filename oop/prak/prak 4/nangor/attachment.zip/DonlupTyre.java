public class DonlupTyre implements Tyre {
    private int pressure;
    private int width;

    public DonlupTyre(int pressure, int width) {
        // Konstruktor
    }

    @Override
    public String getTyreName() {
        // Kembalikan "Donlup"
    }

    @Override
    public int getTyrePressure() {
        // Kembalikan nilai pressure
    }

    @Override
    public int getTyreWidth() {
        // Kembalikan nilai width
    }
}
