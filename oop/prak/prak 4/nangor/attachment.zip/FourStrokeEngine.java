public class FourStrokeEngine implements Engine {
    private int engineCapacity;

    public FourStrokeEngine(int engineCapacity) {
        // Konstruktor
    }

    @Override
    public int getEngineCapacity() {
        // Kembalikan kapasitas mesin
    }

    @Override
    public String sound() {
        // Kembalikan "brumbrum"
    }
}
