public class TwoStrokeEngine implements Engine {
    private int engineCapacity;

    public TwoStrokeEngine(int engineCapacity) {
        // Konstruktor
    }

    @Override
    public int getEngineCapacity() {
        // Kembalikan kapasitas mesin
    }

    @Override
    public String sound() {
        // Kembalikan "taktaktak"
    }
}
