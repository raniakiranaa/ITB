public class MachelinTyre implements Tyre {
    private int pressure;

    public MachelinTyre(int pressure) {
        // Konstruktor
    }

    @Override
    public String getTyreName() {
        // Kembalikan Machelin
    }

    @Override
    public int getTyrePressure() {
        // Kembalikan nilai pressure
    }

    @Override
    public int getTyreWidth() {
        // Kembalikan 200
    }
}
