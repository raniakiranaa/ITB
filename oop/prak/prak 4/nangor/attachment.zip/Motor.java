/**
 * Motor.java
 * [Jelaskan kegunaan class ini]
 * @author [NIM] [Nama]
 */
public class Motor {
    private int numberOfWheels;
    private Engine engine;
    private Tyre tyre;
  
    public Motor(int numberOfWheels, Engine engine, Tyre tyre) {
        // Konstruktor
    }

    public void setEngine(Engine engine) {
        // Mengeset mesin motor
    }

    public void setTyre(Tyre tyre) {
        // Mengeset ban motor
    }

    public Engine getEngine() {
        // Mengembalikan mesin
    }

    public Tyre getTyre() {
        // Mengembalikan ban
    }
    
    public String sound(){
        //Mengembalikan string berisi suara mesin
    }

    public void printDescription() {
        //Mengembalikan string berformat "Motor ini memiliki a roda dengan kapasitas mesin b cc", dimana a adalah numberOfWheels dan b adalah engineCapacity
    }
}