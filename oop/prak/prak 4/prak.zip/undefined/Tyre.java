public interface Tyre {
    public int getTyrePressure();

    public int getTyreWidth();

    public Boolean isSlickTyre();
}
